# 🌞 Otocoin × FusionSolar Entegrasyon Rehberi

Mevcut Otocoin paneline (Railway'de çalışan) Huawei FusionSolar inverter verilerini ekler.

## 🏗️ Mimari

```
GitHub Actions (cron, her 10 dk)
    ↓
fusion_solar.py
    ↓ (FusionSolar API)
Huawei SmartPVMS Cloud
    ↓
fusion_data.json
    ↓ (git push)
GitHub repo (epias-ptf)
    ↓ (github_oku fonksiyonu)
Railway: ofis_panel.py
    ↓ (/api/inverter)
Tarayıcı: 🌞 İnverter sekmesi
```

Bu yapı sayesinde:
- Railway'i değiştirmeden veri akar (GitHub bir veri katmanı)
- F2Pool, OSOS ile aynı mimari (`github_oku("dosya.json")`)
- Rate limit problemi yok (Action'da tek login, panel sadece JSON okuyor)

---

## 📦 Kurulum Adımları

### 1. Dosyaları repo'ya ekle

`epias-ptf` repo'sunun **kök dizinine** şu dosyaları ekle:

```
epias-ptf/
├── ofis_panel.py           ← MEVCUT (patch'lenecek)
├── fusion_solar.py         ← YENİ ekle
└── .github/
    └── workflows/
        └── fusion-sync.yml ← YENİ ekle (cron job)
```

### 2. GitHub Secrets ekle

GitHub repo → Settings → Secrets and variables → Actions → "New repository secret":

| Secret Name | Değer |
|-------------|-------|
| `FUSION_USER` | `aksaray_api10` |
| `FUSION_PASS` | `Ae2026api!` |
| `FUSION_BASE_URL` | `https://sg5.fusionsolar.huawei.com` |

### 3. GitHub Actions'ı etkinleştir

Repo → Actions sekmesi → "I understand my workflows, go ahead and enable them"

İlk çalışma için:
- Actions → "🌞 FusionSolar Data Sync" → "Run workflow" → "Run workflow"

5 dakika içinde `fusion_data.json` otomatik commit edilecek.

### 4. ofis_panel.py'ye Inverter sekmesini ekle

`ofis_panel_PATCH.py` dosyasındaki 6 parçayı sırayla `ofis_panel.py`'ye işle:

**Parça 1** — Tab bar'a OSOS'tan sonra ekle:
```html
<div class="tab" onclick="sekme('inverter', this)">🌞 İnverter</div>
```

**Parça 2** — OSOS tab-content'inin altına yeni `<div class="tab-content" id="t-inverter">` bloğu

**Parça 3** — Modal overlay'in yanına Inverter modal'ı

**Parça 4** — JavaScript: `sekme()` fonksiyonunun altına `invYukle()` ve diğer fonksiyonlar

**Parça 5** — Python endpoint: `/api/inverter` route

**Parça 6** — JS'deki `sekme()` içindeki `if (ad === 'osos')` satırının altına `if (ad === 'inverter') invYukle();`

### 5. Railway redeploy

GitHub'a push edince Railway otomatik redeploy yapacak. Yapmıyorsa:
- Railway dashboard → Deployments → "Redeploy"

### 6. Test et

Panele gir → 🌞 İnverter sekmesi → veriler yüklenmeli.

---

## 🧪 Lokal Test

GitHub Actions'ı beklemeden test etmek için:

```bash
# Lokal makinende (DNS sorununun olmadığı yerde)
export FUSION_USER=aksaray_api10
export FUSION_PASS=Ae2026api!
export GH_TOKEN=ghp_xxxxx  # opsiyonel, GitHub'a push için
export GH_REPO=ekinciomer-ai/epias-ptf

python fusion_solar.py
```

Çıktı:
```
🌞 FusionSolar veri toplama başladı | 2026-05-13T14:30:00
🔐 Login...
✅ Login OK
🏭 Tesisler...
   2 tesis
📡 Cihazlar...
   20 cihaz, 18 inverter
⚡ Anlık veriler...
   Anlık: 1620.5 kW | Bugün: 7850.3 kWh
📊 Günlük üretim...
📅 Aylık üretim...
💾 fusion_data.json kaydedildi
✅ GitHub push OK: fusion_data.json
```

---

## 📊 Veri Şeması — `fusion_data.json`

```json
{
  "timestamp": "2026-05-13T14:30:00",
  "summary": {
    "station_count": 2,
    "inverter_count": 18,
    "total_power_kW": 1620.50,
    "total_day_kWh": 7850.30,
    "total_lifetime_kWh": 2400000,
    "total_capacity_MW": 2.0421
  },
  "stations": [
    {
      "code": "NE=59224704",
      "name": "Tek Yıldız-1 GES",
      "capacity_MW": 1.00713,
      "address": "...",
      "current_power_kW": 850.20,
      "day_energy_kWh": 4200.50,
      "lifetime_kWh": 1200000,
      "inverter_count": 10
    },
    ...
  ],
  "inverters": [
    {
      "devId": 1000000059224717,
      "devName": "Inverter 1",
      "stationName": "Tek Yıldız-1 GES",
      "stationCode": "NE=59224704",
      "activePower_kW": 85.45,
      "dayEnergy_kWh": 420.30,
      "totalEnergy_kWh": 150000,
      "runState": 1,
      "temperature": 35.2
    },
    ...18 adet
  ],
  "daily": {
    "NE=59224704": {
      "stationName": "Tek Yıldız-1 GES",
      "date": "2026-05-13",
      "hourly": {
        "00": { "power_kW": 0, "production_kWh": 0, "radiation": 0 },
        "06": { "power_kW": 85, "production_kWh": 30, "radiation": 200 },
        "12": { "power_kW": 950, "production_kWh": 800, "radiation": 1100 },
        ...
      }
    }
  },
  "monthly": {
    "NE=59224704": {
      "stationName": "Tek Yıldız-1 GES",
      "month": "2026-05",
      "daily": {
        "2026-05-01": { "production_kWh": 5200 },
        "2026-05-02": { "production_kWh": 4900 },
        ...
      }
    }
  }
}
```

---

## ⚠️ Sınırlamalar & Notlar

### Rate Limits
- **Login: 10 dakikada 1** — Cron 10 dk'ya ayarlı, sınırı aşmaz
- **getStationList: 5 dk'da 1** — OK
- **getDevRealKpi: dk'da 10** — OK (tek istekte 18 inverter)

### Veri Tazeliği
- Veriler **maksimum 10 dakika** gecikmeli
- Daha sık gerekiyorsa `cron: '*/5 * * * *'` yap (ama login limitine dikkat)

### GitHub Actions Limit
- Public repo: **2000 dakika/ay free** — 10 dk'da bir × her çalışma ~1 dk = ~4320 dk/ay → **limit aşılır!**
- Çözüm: Cron'u 15 dakikaya çıkar (`*/15 * * * *`) → ~2880 dk/ay (yine aşar)
- Veya cron'u 30 dakikaya çıkar (`*/30 * * * *`) → ~1440 dk/ay ✅ Güvenli

**Önerim**: 15 dakika cron + manuel "Run workflow" gerektiğinde

### Alternatif: Railway'de çalıştır
GitHub Actions yerine Railway'de cron job olarak çalıştırabilirsin. Railway'in built-in cron desteği vardır:
- `railway.toml` veya Dashboard'dan "Cron Job" servisi ekle
- Komut: `python fusion_solar.py`
- Schedule: `*/10 * * * *`

Bu durumda Railway'in environment variables'ına `FUSION_USER`, `FUSION_PASS` ekle. GitHub push'a gerek kalmaz, fusion_data.json'u doğrudan Railway diskinde tut ve panel direkt okusun (file path ile).

---

## 🔐 Güvenlik

- ✅ Şifre repo'da hard-code değil, GitHub Secrets'ta
- ✅ fusion_data.json public, ama sadece üretim verileri (hassas değil)
- ⚠️ Şifreyi DEĞİŞTİR: `Ae2026api!` test şifresiydi, production için güçlü şifre yap
- ⚠️ `GH_TOKEN` Personal Access Token, "Contents: write" yetkisi yeter

---

## 🐛 Sorun Giderme

### `failCode: 20400`
Şifre yanlış veya Northbound kullanıcı tipi yanlış. FusionSolar portalda kontrol et.

### `failCode: 305` (session expired)
fusion_solar.py otomatik retry yapar. Sorun çıkarsa cron'u yeniden tetikle.

### GitHub Actions çalışmıyor
- Repo → Settings → Actions → "Allow all actions" işaretli mi?
- Workflow file `.github/workflows/fusion-sync.yml` yolunda mı?
- Secrets girilmiş mi?

### Panel "Veri yok" diyor
- GitHub Actions çalıştı mı? (Repo → Actions sekmesi)
- `fusion_data.json` repo'da var mı?
- Railway redeploy oldu mu?
