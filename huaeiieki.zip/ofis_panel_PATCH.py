"""
ofis_panel.py - INVERTER SEKMESİ PATCH
========================================

Bu patch'i mevcut ofis_panel.py dosyana üç yerde ekleyeceksin:

1. TABS satırına yeni sekme
2. PANEL_HTML'in tab-content blokları arasına yeni tab
3. PANEL_HTML += script bölümünün başına inverter render fonksiyonu
4. Sonuna yeni /api/inverter endpoint'i

Aşağıda her parça için tam kopyalanacak kodlar var.
"""

# ============================================================
# PARÇA 1: TAB BAR'A EKLE
# ============================================================
# Mevcut bu satırı bul:
#     <div class="tab" onclick="sekme('osos', this)">🔋 OSOS</div>
#
# ALTINA şunu ekle:

TAB_BUTTON = '''<div class="tab" onclick="sekme('inverter', this)">🌞 İnverter</div>'''


# ============================================================
# PARÇA 2: TAB-CONTENT BLOKLARI ARASINA EKLE
# ============================================================
# Mevcut bu blokun KAPANIŞINDAN SONRA ekle:
#     <div class="tab-content" id="t-osos"> ... </div>
#
# (yani </div> </div> ile biten OSOS bloğunun hemen altına)

TAB_CONTENT = '''
<div class="tab-content" id="t-inverter">

<div class="status-card" id="inverter-status">
<div class="status-row">
<div class="status-icon" style="background:linear-gradient(135deg,#f59e0b,#fbbf24)">☀️</div>
<div>
<div class="status-title" id="inv-anlik">— kW</div>
<div class="status-sub" id="inv-sub">— inverter aktif</div>
</div>
</div>
</div>

<div class="kpi-grid">
<div class="kpi-card highlight">
<div class="kpi-label">📅 Bugünkü Üretim</div>
<div class="kpi-value" id="inv-bugun" style="color:#fbbf24">—</div>
<div class="kpi-sub">kWh</div>
</div>
<div class="kpi-card">
<div class="kpi-label">⚡ Anlık Toplam</div>
<div class="kpi-value" id="inv-kw" style="color:#4ade80">—</div>
<div class="kpi-sub">kW</div>
</div>
<div class="kpi-card">
<div class="kpi-label">♾️ Ömür Boyu</div>
<div class="kpi-value" id="inv-omur" style="color:#60a5fa">—</div>
<div class="kpi-sub">MWh</div>
</div>
<div class="kpi-card">
<div class="kpi-label">🏭 Kapasite</div>
<div class="kpi-value" id="inv-kapasite" style="color:#a78bfa">—</div>
<div class="kpi-sub">MW kurulu</div>
</div>
</div>

<div class="section-header">
<div class="section-title">🏭 Tesisler</div>
<div style="font-size:10px;color:#64748b" id="inv-time">—</div>
</div>
<div id="inv-stations" style="margin-bottom:14px"></div>

<div class="osos-section-tabs">
<button class="osos-sec-tab active" onclick="invSec('liste', this)">🖥️ İnverter Listesi</button>
<button class="osos-sec-tab" onclick="invSec('saatlik', this)">📊 Saatlik Üretim</button>
<button class="osos-sec-tab" onclick="invSec('aylik', this)">📅 Aylık</button>
</div>

<div class="osos-sec-content active" id="inv-sec-liste">
<div class="cihaz-grid" id="inv-grid"><div class="empty-state" style="grid-column:1/-1">Yükleniyor...</div></div>
</div>

<div class="osos-sec-content" id="inv-sec-saatlik">
<div class="osos-tabs" id="inv-station-tabs"></div>
<div class="chart-wrap">
<div class="chart-title">📊 Bugünkü Saatlik Üretim (kWh)</div>
<canvas class="chart-canvas" id="inv-daily-chart"></canvas>
</div>
<div class="aylik-wrap" style="margin-top:12px">
<table class="aylik-table">
<thead><tr><th class="saat-head">Saat</th><th>Güç (kW)</th><th>Üretim (kWh)</th><th>Radyasyon</th></tr></thead>
<tbody id="inv-saatlik-body"></tbody>
</table>
</div>
</div>

<div class="osos-sec-content" id="inv-sec-aylik">
<div id="inv-aylik-liste"><div class="empty-state">Yükleniyor...</div></div>
</div>

</div>
'''


# ============================================================
# PARÇA 3: MODAL'A İNVERTER DETAY (opsiyonel, varolan modal'a yeni kart)
# ============================================================
# Mevcut Modal yapısının altında yer alacak yeni inverter modal'ı:
# Varolan cihaz modalını referans aldık, aynı stille.

INVERTER_MODAL = '''
<div class="modal-overlay" id="inv-modal" onclick="if(event.target.id==='inv-modal')kapatInvModal()">
<div class="modal">
<button class="modal-close" onclick="kapatInvModal()">✕</button>
<div class="modal-header">
<div class="modal-icon" style="background:linear-gradient(135deg,#f59e0b,#fbbf24)">☀️</div>
<div><div class="modal-title" id="im-title">—</div><div class="modal-sub" id="im-sub">—</div></div>
</div>
<div class="modal-stats">
<div class="modal-stat"><div class="modal-stat-lbl">Anlık Güç</div><div class="modal-stat-val" style="color:#4ade80" id="im-anlik">—</div><div class="modal-stat-sub">kW</div></div>
<div class="modal-stat"><div class="modal-stat-lbl">Bugün</div><div class="modal-stat-val" style="color:#fbbf24" id="im-bugun">—</div><div class="modal-stat-sub">kWh</div></div>
<div class="modal-stat"><div class="modal-stat-lbl">Ömür Boyu</div><div class="modal-stat-val" style="color:#60a5fa" id="im-omur">—</div><div class="modal-stat-sub">MWh</div></div>
<div class="modal-stat"><div class="modal-stat-lbl">Durum</div><div class="modal-stat-val" id="im-durum">—</div><div class="modal-stat-sub" id="im-sicaklik">—</div></div>
</div>
</div>
</div>
'''


# ============================================================
# PARÇA 4: JAVASCRIPT (PANEL_HTML += script bloğunun İÇİNE EKLE)
# ============================================================
# sekme() fonksiyonunun ALTINA ekle, en üst kısma yerleştir.

INVERTER_JS = '''
// === İNVERTER SEKME (Huawei FusionSolar) ===
let invData = null;
let invSecilenIstasyon = null;

// Mevcut sekme() fonksiyonuna inverter desteği ekle:
// "if (ad === 'osos') ososYukle();" satırından SONRA şunu ekle:
//     if (ad === 'inverter') invYukle();

function invYukle() {
    if (invData) { invRender(); return; }
    document.getElementById('inv-anlik').textContent = 'Yükleniyor...';
    fetch('/api/inverter').then(r => r.json()).then(d => {
        if (d.hata) {
            document.getElementById('inv-anlik').textContent = 'Veri yok';
            document.getElementById('inv-sub').textContent = d.hata;
            return;
        }
        invData = d;
        invRender();
    }).catch(e => {
        document.getElementById('inv-anlik').textContent = 'Hata';
    });
}

function invSec(sec, btn) {
    btn.parentElement.querySelectorAll('.osos-sec-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('#t-inverter .osos-sec-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('inv-sec-' + sec).classList.add('active');
    if (sec === 'saatlik' && invData && invData.stations.length > 0 && !invSecilenIstasyon) {
        invIstasyonSec(invData.stations[0].code);
    }
}

function invRender() {
    if (!invData) return;
    const s = invData.summary;

    document.getElementById('inv-anlik').textContent = s.total_power_kW.toLocaleString('tr-TR') + ' kW';
    document.getElementById('inv-sub').textContent = s.inverter_count + ' inverter | ' + s.station_count + ' tesis';
    document.getElementById('inv-bugun').textContent = Math.round(s.total_day_kWh).toLocaleString('tr-TR');
    document.getElementById('inv-kw').textContent = Math.round(s.total_power_kW).toLocaleString('tr-TR');
    document.getElementById('inv-omur').textContent = (s.total_lifetime_kWh / 1000).toFixed(1);
    document.getElementById('inv-kapasite').textContent = s.total_capacity_MW.toFixed(2);
    document.getElementById('inv-time').textContent = 'Güncel: ' + new Date(invData.timestamp).toLocaleTimeString('tr-TR');

    // Tesis kartları
    let stHtml = '';
    invData.stations.forEach(st => {
        const oran = st.capacity_MW > 0 ? (st.current_power_kW / (st.capacity_MW * 1000) * 100) : 0;
        stHtml += '<div class="osos-info ges" style="margin-bottom:8px">'
            + '<div class="osos-info-ico">☀️</div>'
            + '<div style="flex:1">'
            + '<div class="osos-info-title">' + st.name + '</div>'
            + '<div class="osos-info-sub">' + st.inverter_count + ' inverter · ' + st.capacity_MW.toFixed(3) + ' MW kurulu</div>'
            + '</div>'
            + '<div style="text-align:right">'
            + '<div style="font-size:18px;font-weight:900;color:#fbbf24">' + Math.round(st.current_power_kW) + '</div>'
            + '<div style="font-size:10px;color:#94a3b8">kW · %' + Math.round(oran) + '</div>'
            + '</div>'
            + '</div>';
    });
    document.getElementById('inv-stations').innerHTML = stHtml;

    // İnverter grid
    let gridHtml = '';
    invData.inverters.forEach(inv => {
        const aktif = inv.activePower_kW > 0;
        const cls = aktif ? '' : (inv.runState === 0 ? 'kapali' : 'uyuyor');
        const badge = aktif ? 'badge-on' : (inv.runState === 0 ? 'badge-off' : 'badge-sleep');
        const lbl = aktif ? 'Çalışıyor' : (inv.runState === 0 ? 'Stop' : 'Standby');
        gridHtml += '<div class="cihaz-card ' + cls + '" onclick="invDetay(\\'' + inv.devId + '\\')">'
            + '<div class="cihaz-row1">'
            + '<div class="cihaz-no" style="font-size:14px">' + inv.devName + '</div>'
            + '<div class="cihaz-badge ' + badge + '">' + lbl + '</div>'
            + '</div>'
            + '<div class="cihaz-hash" style="color:#fbbf24">' + inv.activePower_kW.toFixed(1) + ' <span style="font-size:11px;color:#64748b">kW</span></div>'
            + '<div class="cihaz-sub">Bugün: ' + Math.round(inv.dayEnergy_kWh) + ' kWh · ' + inv.stationName.replace(' GES','') + '</div>'
            + '</div>';
    });
    document.getElementById('inv-grid').innerHTML = gridHtml || '<div class="empty-state" style="grid-column:1/-1">İnverter yok</div>';

    // Saatlik istasyon tabları
    let stTabsHtml = '';
    invData.stations.forEach((st, i) => {
        stTabsHtml += '<button class="osos-tab' + (i === 0 ? ' active' : '') + '" onclick="invIstasyonSec(\\'' + st.code + '\\', this)">' + st.name.replace(' GES','') + '</button>';
    });
    document.getElementById('inv-station-tabs').innerHTML = stTabsHtml;

    if (invData.stations.length > 0) {
        invIstasyonSec(invData.stations[0].code);
    }

    // Aylık
    invAylikRender();
}

function invIstasyonSec(code, btn) {
    if (btn) {
        document.querySelectorAll('#inv-station-tabs .osos-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }
    invSecilenIstasyon = code;
    const daily = invData.daily[code];
    if (!daily) {
        document.getElementById('inv-saatlik-body').innerHTML = '<tr><td colspan="4" class="empty-state">Veri yok</td></tr>';
        return;
    }

    // Saatlik tablo
    let tbody = '';
    let toplam = 0;
    const chartData = [];
    for (let h = 0; h < 24; h++) {
        const hk = String(h).padStart(2, '0');
        const d = daily.hourly[hk] || { power_kW: 0, production_kWh: 0, radiation: 0 };
        toplam += d.production_kWh;
        chartData.push({ label: hk, value: d.production_kWh });
        const cls = renkSinif(d.production_kWh * 5);
        tbody += '<tr>'
            + '<td class="saat-cell">' + hk + ':00</td>'
            + '<td class="' + cls + '">' + (d.power_kW ? d.power_kW.toFixed(1) : '—') + '</td>'
            + '<td class="' + cls + '">' + (d.production_kWh ? d.production_kWh.toFixed(1) : '—') + '</td>'
            + '<td class="l2">' + (d.radiation ? d.radiation.toFixed(2) : '—') + '</td>'
            + '</tr>';
    }
    tbody += '<tr style="border-top:2px solid rgba(34,197,94,0.4)">'
        + '<td class="saat-cell" style="background:linear-gradient(180deg,#16a34a,#15803d);color:white">TOP</td>'
        + '<td>—</td>'
        + '<td class="l0" style="font-weight:900">' + Math.round(toplam).toLocaleString('tr-TR') + '</td>'
        + '<td>—</td>'
        + '</tr>';
    document.getElementById('inv-saatlik-body').innerHTML = tbody;

    // Grafik
    cizGrafikLine('inv-daily-chart', chartData);
}

function invAylikRender() {
    if (!invData || !invData.monthly) return;
    let html = '';
    Object.entries(invData.monthly).forEach(([code, m]) => {
        const days = Object.keys(m.daily).sort();
        let toplam = 0;
        days.forEach(d => toplam += (m.daily[d].production_kWh || 0));

        html += '<div class="yillik-card">'
            + '<div class="yillik-title">☀️ ' + m.stationName + ' · ' + m.month + '</div>'
            + '<div class="yillik-grid">'
            + '<div class="yillik-stat"><div class="yillik-lbl">Bu Ay Üretim</div><div class="yillik-val" style="color:#fbbf24">' + Math.round(toplam).toLocaleString('tr-TR') + '</div><div class="yillik-lbl">kWh</div></div>'
            + '<div class="yillik-stat"><div class="yillik-lbl">Gün Sayısı</div><div class="yillik-val" style="color:#4ade80">' + days.length + '</div><div class="yillik-lbl">gün</div></div>'
            + '<div class="yillik-stat"><div class="yillik-lbl">Günlük Ort.</div><div class="yillik-val" style="color:#60a5fa">' + (days.length ? Math.round(toplam / days.length).toLocaleString('tr-TR') : 0) + '</div><div class="yillik-lbl">kWh</div></div>'
            + '</div></div>';
    });
    document.getElementById('inv-aylik-liste').innerHTML = html || '<div class="empty-state">Veri yok</div>';
}

function invDetay(devId) {
    if (!invData) return;
    const inv = invData.inverters.find(i => String(i.devId) === String(devId));
    if (!inv) return;
    document.getElementById('im-title').textContent = inv.devName;
    document.getElementById('im-sub').textContent = inv.stationName;
    document.getElementById('im-anlik').textContent = inv.activePower_kW.toFixed(2);
    document.getElementById('im-bugun').textContent = Math.round(inv.dayEnergy_kWh).toLocaleString('tr-TR');
    document.getElementById('im-omur').textContent = (inv.totalEnergy_kWh / 1000).toFixed(1);
    document.getElementById('im-durum').textContent = inv.runState === 1 ? '🟢 Çalışıyor' : (inv.runState === 0 ? '🔴 Stop' : '🟡 Standby');
    document.getElementById('im-sicaklik').textContent = inv.temperature ? inv.temperature.toFixed(1) + ' °C' : '—';
    document.getElementById('inv-modal').classList.add('active');
}

function kapatInvModal() { document.getElementById('inv-modal').classList.remove('active'); }
'''


# ============================================================
# PARÇA 5: API ENDPOINT (sınıfın altına ekle, /api/ozet'ten önce/sonra)
# ============================================================

API_ENDPOINT = '''
@app.route("/api/inverter")
def inverter():
    """Huawei FusionSolar inverter verileri - GitHub'dan fusion_data.json okur."""
    if "kullanici" not in session:
        return jsonify({"hata":"yetkisiz"}), 401

    data = github_oku("fusion_data.json")
    if not data:
        return jsonify({"hata":"Veri yok - fusion_solar.py henüz çalışmadı"}), 200

    return jsonify(data)
'''


# ============================================================
# PARÇA 6: sekme() FONKSİYONUNA YENİ KOŞUL EKLE
# ============================================================
# Mevcut JS'deki şu satırı:
#     if (ad === 'osos') ososYukle();
#
# Şununla değiştir:

SEKME_GUNCELLEME = '''
    if (ad === 'osos') ososYukle();
    if (ad === 'inverter') invYukle();
'''


print(__doc__)
print("\nBu dosya bir patch rehberidir. Yukarıdaki PARÇA 1-6'yı ofis_panel.py'ye işle.")
print("Veya 'ofis_panel_patched.py' dosyasını doğrudan kullan.")
